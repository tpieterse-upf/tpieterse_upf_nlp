Sources of data:
	https://universaldependencies.org/#download

Required packages:
	numpy
	spacy
	