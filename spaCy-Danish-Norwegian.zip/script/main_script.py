# -*- coding: utf-8 -*-
"""
Created on Sun Feb 26 13:49:00 2023

@author: Tommy Pieterse
"""

import numpy as np
import spacy

# Load Danish and Norwegian spaCy models
dkp_dk = spacy.load("da_core_news_sm")
dkp_nb = spacy.load("nb_core_news_sm")

# Specify paths to treebank files
danish_path = r"data\UD_Danish-DDT\da_ddt-ud-train.conllu"
norwegian_path = r"data\UD_Norwegian-Bokmaal\no_bokmaal-ud-train.conllu"
        
# Function that aids in recording the treebank data heads the same way as spaCy does (i.e., the head as a string instead of idx+1)
def get_head(input_list, main_list):
    idx = input_list[1] # Get index of head in sentence from input
    if idx == "0": # 0 is ROOT
        input_list[1] = input_list[0] # Return the string of the current token
        return input_list # Return new list as replacement
    elif idx == r"_": # _ not compatible with indexing of token, return _ (rare)
        input_list[1] = "_"
        return input_list
    idx = int(idx) - 1 # Get index that starts at 0 instead of 1

    item = main_list[idx] # Get head string based on index
    input_list[1] = item[0] # Replace index in list with string
    
    
    return input_list # Return new list as replacement

# Function used for extracting the text and tokens from a string
def sent_process(input_str):
    lines = input_str.split("\n") # Split by newline
    lines = [x for x in lines if x] # Remove empty lines
    text = [x for x in lines if x.startswith(r"# text")][0] # Identify text by tag
    text = text.replace(r"# text = ", "") # Remove tag
    
    sentlines = [x for x in lines if not x.startswith(r"#")] # Remove lines containing metadata (start with #)
    sentlines = [x for x in sentlines if not x.startswith(r"id")] # Remove id metadata

    sentlines = [x.split("\t") for x in sentlines] # Split by tab (getting text/head/deps per token)
    sentlines = [[x[1], x[6], x[7]] for x in sentlines if len(x) > 6] # Get text/head/deps and leave out text that's too short
    sentlines = [get_head(x, sentlines) for x in sentlines] # Replace head index with actual head string (like in spaCy)
    return {"text": text, "golden_tokens": sentlines} # Return dictionary with data

# Function used to compute statistics for each entered sentence dictionary
def compute_stats(input_dict):
    gold_sent = input_dict["golden_tokens"] # Get golden standard tokens and heads/deps
    spacy_sent = input_dict["spacy_tokens"] # Same for the spaCy data
    
    gold_toknames = [x[0] for x in gold_sent] # Get token text
    spacy_toknames = [x[0] for x in spacy_sent] # Get token text
    
    pop_list_full = spacy_sent[:] # Copy list of text/head/deps per token
    pop_list = spacy_toknames[:] # Copy lsit of token text
    correct_count = 0 # Initialize counter for correct predictions
    incorrect_count = 0 # Initialize counter for incorrect predictions
    
    gold_heads = [] # Initialize list for collecting gold heads
    spacy_heads = [] # Same for spaCy heads
    gold_deps = [] # Same for gold dependency types
    spacy_deps = [] # Same for spaCy dependency types

    for idx, token in enumerate(gold_toknames): # For every token in gold standard
        if token in pop_list: # If token also in spaCy tokens
            correct_count += 1 # Increase correct count
            extract_index = pop_list.index(token) # Get index for that token in spaCy list
            extracted_full = pop_list_full.pop(pop_list.index(token)) # Pop that out of text/head/dep list (and keep)
            pop_list.pop(pop_list.index(token)) # Same for list with just the text for the token
            
            gold_heads.append(gold_sent[idx][1]) # Save gold head for token
            spacy_heads.append(extracted_full[1]) # Save spaCy head for token
            gold_deps.append(gold_sent[idx][2]) # Save gold dep for token
            spacy_deps.append(extracted_full[2]) # Save spaCy dep for token
        else:
            incorrect_count += 1 # Otherwise, add to incorrect count
    
    tokenizer_accuracy = correct_count / (correct_count + incorrect_count) # Compute accuracy for tokenization
    
    correct_heads = 0 # Initialize counter for correct heads
    incorrect_heads = 0 # and incorrect heads
    for pair in zip(gold_heads, spacy_heads): # Compare gold heads with their spaCy counterparts
        if pair[0] == pair[1]: # If the same...
            correct_heads += 1 # Increase correct counter
        else: # Otherwise,
            incorrect_heads += 1 # Increase incorrect counter
    heads_accuracy = correct_heads / (incorrect_heads + correct_heads) # Compute accuracy
    
    correct_deps = 0 # (Code section functions the same as above but for the deps)
    incorrect_deps = 0
    for pair in zip(gold_deps, spacy_deps):
        if pair[0] == pair[1]:
            correct_deps += 1
        else:
            incorrect_deps += 1
    deps_accuracy = correct_deps / (incorrect_deps + correct_deps)


    return_dict = { # Create dictionary with relevant data to return
        "tokenizer_acc": tokenizer_accuracy,
        "heads_acc": heads_accuracy,
        "deps_acc":deps_accuracy,
    }
    return return_dict


# Read datasets as strings
with open(danish_path, "r", encoding = "utf-8") as handle:
    danish_string = handle.read()
    
with open(norwegian_path, "r", encoding = "utf-8") as handle:
    norwegian_string = handle.read()


# Split datasets by sentence and then remove empty lines
danish_sents = danish_string.split(r"# sent_")
danish_sents = [sent_process(x) for x in danish_sents if x] # Remove empty lines

norwegian_sents = norwegian_string.split(r"# sent_")
norwegian_sents = [sent_process(x) for x in norwegian_sents if x and not x.startswith("# newdoc")] # Remove empty lines


# Process sentences for Danish with spaCy
full_sents_dk = [] # Initialize list to collect sentences in
for elem in danish_sents: # For every sentence
    sentence = elem["text"] # Get text
    if len(sentence) < 10: # If sentence too short, leave it out of the data
        continue
    doc = dkp_dk(sentence) # Put sentence into pipeline
    tokens = [] # Initialize empty list for the tokens and their data
    for t in doc: # For every token,
        tokens.append([t.text, str(t.head), t.dep_.lower()]) # Get text, head and dependency (lower case for domparability)
    elem["spacy_tokens"] = tokens # Add tokens to dictionary
    full_sents_dk.append(elem) # Add dictionary to initialized list

full_sents_nb = [] # Same process as above here except for Norwegian
for elem in norwegian_sents:
    sentence = elem["text"]
    if len(sentence) < 10:
        continue
    doc = dkp_nb(sentence)
    tokens = []
    for t in doc:
        tokens.append([t.text, str(t.head), t.dep_.lower()])
    elem["spacy_tokens"] = tokens
    full_sents_nb.append(elem)

# Calculate metrics:
dk_tokacc = np.array([compute_stats(x)["tokenizer_acc"] for x in full_sents_dk]).mean() # Get mean tokenizer accuracy over all sentences
dk_headsacc = np.array([compute_stats(x)["heads_acc"] for x in full_sents_dk]).mean() # Get mean head accuracy
dk_depsacc = np.array([compute_stats(x)["deps_acc"] for x in full_sents_dk]).mean() # Get mean dependency type accuracy

nb_tokacc = np.array([compute_stats(x)["tokenizer_acc"] for x in full_sents_nb]).mean() # Same again but for Norwegian
nb_headsacc = np.array([compute_stats(x)["heads_acc"] for x in full_sents_nb]).mean()
nb_depsacc = np.array([compute_stats(x)["deps_acc"] for x in full_sents_nb]).mean()

# Print statistics
print("Statistics for Danish:")
print("  Tokenization accuracy", dk_tokacc)
print("  Head accuracy", dk_headsacc)
print("  Dependency type accuracy", dk_depsacc)
print("")
print("Statistics for Norwegian:")
print("  Tokenization accuracy", nb_tokacc)
print("  Head accuracy", nb_headsacc)
print("  Dependency type accuracy", nb_depsacc)